package com.gears.mymaps

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.gears.mymaps.databinding.ActivityMapsBinding
import com.google.android.gms.maps.model.*
import java.util.jar.Manifest

class MapsActivity : AppCompatActivity(), OnMapReadyCallback
{

    private lateinit var mObjMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private val TAG = MapsActivity::class.java.simpleName
    private val LOCATION_PERMISSION = 1

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mObjMap = googleMap

        val lObjLatitude = 27.2046
        val lObjLongitude = 77.4977
        val lObjZoom = 15f
        val lObjMyLocation = LatLng(lObjLatitude, lObjLongitude)
        mObjMap.addMarker(MarkerOptions().position(lObjMyLocation).title("my location $lObjLatitude , $lObjLongitude"))
        mObjMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lObjMyLocation,lObjZoom))
        onMapLongClick(mObjMap)
        setPoi(mObjMap)
        setMapStyle(mObjMap)
        enableMyLocation()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean
    {
        val inflater = menuInflater
        inflater.inflate(R.menu.maps_type, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean
    {
        when (item.itemId)
        {
            R.id.normal -> {
                mObjMap.mapType = GoogleMap.MAP_TYPE_NORMAL
            }
            R.id.hybrid -> {
                mObjMap.mapType = GoogleMap.MAP_TYPE_HYBRID
            }
            R.id.satellite -> {
                mObjMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
            }
            R.id.terrain -> {
                mObjMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun onMapLongClick(pObjMap : GoogleMap)
    {
        pObjMap.setOnMapLongClickListener {
            latLng ->
            val snippet = "lat: ${latLng.latitude} lng: ${latLng.longitude}"
            pObjMap.addMarker(MarkerOptions()
                .position(latLng)
                .title("Location")
                .snippet(snippet)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
            )

        }
    }

    private fun setPoi(pObjMap : GoogleMap)
    {
        pObjMap.setOnPoiClickListener{
            poi->
            val lObjPoi = pObjMap.addMarker(MarkerOptions().position(poi.latLng).title(poi.name).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)))
            lObjPoi.showInfoWindow()
        }
    }

    private fun setMapStyle(pObjMap : GoogleMap)
    {
        pObjMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this,R.raw.map_style))
    }

    private fun isPermissionGranted() : Boolean
    {
       return ContextCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION )== PackageManager.PERMISSION_GRANTED
    }

    /**
     * enable the location data layer if permission is granted else ask the user to grant permission
     * we will get a callback at onRequestPermissionsResult
     */
    private fun enableMyLocation()
    {
        try {
            if(isPermissionGranted())
            {
                mObjMap.setMyLocationEnabled(true)
            }
            else{
                ActivityCompat.requestPermissions(this, arrayOf<String>(android.Manifest.permission.ACCESS_FINE_LOCATION),LOCATION_PERMISSION)
            }
        } catch (e: Exception) {
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray) {
        // Check if location permissions are granted and if yes then enable the location data layer
        if (requestCode == LOCATION_PERMISSION) {
            if (grantResults.size > 0 && (grantResults[0] == PackageManager.PERMISSION_GRANTED))
            {
                enableMyLocation()
            }
        }
    }
}